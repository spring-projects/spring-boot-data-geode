package example.app.initializer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InitializerApplicationTests {

	@Test
	void contextLoads() {
	}

}
